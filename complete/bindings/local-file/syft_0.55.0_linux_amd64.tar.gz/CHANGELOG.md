# Changelog

## [(Unreleased)](https://github.com/anchore/syft/tree/a7966a4d9d8155be788af33fe5e5af2e40043f82) (2022-08-29)

[Full Changelog](https://github.com/anchore/syft/compare/v0.54.0...a7966a4d9d8155be788af33fe5e5af2e40043f82)

### Added Features

- Capture package.json private field for npm modules [[Issue #1160](https://github.com/anchore/syft/issues/1160)]
- add support for pnpm [[Issue #1165](https://github.com/anchore/syft/issues/1165)]

### Bug Fixes

- Java-Cataloger produces empty entries for cyclonedx output [[Issue #466](https://github.com/anchore/syft/issues/466)]
- No licenses included in scan with yarn.lock [[Issue #845](https://github.com/anchore/syft/issues/845)]
- syft convert -o option erroring out  [[Issue #1095](https://github.com/anchore/syft/issues/1095)]


